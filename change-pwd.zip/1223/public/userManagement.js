$(document).ready(function() {
    $.ajax({
        method: 'get',
        url: '/my-info',
        
    }).done(function (data) {
        console.log(data);
        if(data.success) {
            $('#current-email').html(`<span>${data.user.email}</span>`);
            $('#current-id').html(`<span>${data.user.uid}</span>`);
            $('#myinfo').html(`<span>${data.user.uid}</span>`);
            $('#current-password').html(`<span>${data.user.pwd}</span>`);
        } else {
            $('#msg-alert').text(data.msg);
        }
    });

    
});



//이메일 변경
$('#btn-email-change').click(function (){
    
   
   
});

//아이디 변경
$('#btn-account-change').click(function (){
   
   
});

//비밀번호 변경
$('#btn-password-change').click(function (){

    var prevPwd = $('#input-user-pwd').val();
    var newPwd = $('#input-user-newpwd').val();
    $.ajax({
        method: 'put',
        url : '/change-pwd',
        data : {
            prevPwd : prevPwd,
            newPwd : newPwd
        }
    }).done(function(data){
        // console.log(data);
        alert('비밀번호 변경 성공');
        $('#input-user-pwd').val('');
        $('#input-user-newpwd').val('');
    })
   
   
});

