// 이메일 인증
var emailAuthCheck = false;
$('#btn-email-confirm').click(function (){

    var time = 0;
    var min = 0;
    var sec = 3;
    
    if (time == 0) {
        startTimer = setInterval(() => {
            sec--;
            if(sec == 0){
                min--; sec = 59;
                if(min==0 && sec==0){
                    console.log('끝');
                    clearInterval(startTimer);
                    $('#min').addClass('hidden').html('인증실패. 다시시도해주세요');
                    $('#sec').addClass('hidden');
                }
            }
            
            Display();

        }, 1000);
        
    }
    
    //이메일 인증 확인
    $('#btn-email-ok').click(function(){

        //TODO 실제 이메일인증 로직

        emailAuthCheck = true;
        clearInterval(startTimer);
        alert('인증되었습니다.')

        $('#min').addClass('hidden');
        $('#sec').addClass('hidden');
    });

    function Display(){
        if(min < 10){
            $('#min').html('0'+ min + ':');
        } else {
            $('#min').html(min + ':');
        }
        if(sec < 10){
            $('#sec').html('0'+ sec);
        } else {
            $('#sec').html(sec);
        }

        
        
    }
    
});



// 아이디 6글자~12글자 , 영문자, 숫자만 가능 , 숫자시작 불가
$('#btn-account-ok').click(function (){   
    
    var uid = $('#input-user-account').val();
    console.log(uid);
    
    function inspect(userdata) {

        if(userdata.length >= 13 || userdata.length <= 5){
            $('#input-user-account').val('');
            return alert('아이디는 6글자 이상, 12글자 이하로 만들어주세요.');
            
        } else {
            var pattern = /^[0-9]/;
            if(pattern.test(userdata) ) {
                $('#input-user-account').val('');
                return alert('아이디는 숫자로 시작할 수 없습니다.');
            }
            var pattern2 = /[^0-9a-z]/g
            if(pattern2.test(userdata) ){
                $('#input-user-account').val('');
                return alert('아이디는 영문자 및 숫자만 가능합니다.');
            } 
        }
        return alert('사용가능한 아이디입니다.');
    }
    inspect(uid);
});


// 패스워드 : 숫자 영문자 특수문자 1개씩 포함 길이는 6글자 12글자
$('#btn-password-ok').click(function (){  
    var pwd = $('#input-user-password').val();

    function inspect(userdata) {
        if(userdata.length >= 13 || userdata.length <= 5){
            $('#input-user-password').val('');
            return alert('비밀번호는 6글자 이상, 12글자 이하로 만들어주세요.')
        } 
        var patternA = /[0-9]{1}/;
        var patternN = /[a-z]{1}/i;
        var patternS = /[^0-9a-z]{1}/;
        if(!patternA.test(userdata) || !patternN.test(userdata) || !patternS.test(userdata)) {
            $('#input-user-password').val('');
            return alert('비밀번호는 숫자, 영문자 및 특수문자 1개씩 포함 해야합니다.');
        } else {
            return alert('사용가능한 비밀번호입니다.');
        }
        
    }

    inspect(pwd);
});

    //패스워드 2개일치
$('#btn-passwordCopy-ok').click(function (){  
    var pwd = $('#input-user-password').val();
    var pwdCopy = $('#input-user-passwordCopy').val();
    if(pwd !== pwdCopy) {
        return alert('비밀번호 불일치. 다시 확인해주세요')
    } else{
        return alert('비밀번호 일치')
    }
});

// 회원가입 버튼

$('#btn-join').click(function (){
    /*
    이메일 인증이 우선 되어 있는가? => 
    */
    if(!emailAuthCheck) {
        return alert('이메일 인증을 우선 완료해주세요.');
    }  
    var uid = $('#input-user-account').val();
    var pwd = $('#input-user-password').val();
    var email = $('#input-user-email').val();

    

    // 데이터 통신
    $.ajax({
        url : '/signup',
        method: 'post',
        data : {
            uid : uid,
            pwd : pwd,
            email : email
        }
    }).done(function (data) {

        console.log(data);

        if(data.success) {
            alert('회원가입에 성공했습니다.');
            location.href = '/login-ok';
        } else {
            $('#msg-alert').text(data.msg);
        }
    })


});